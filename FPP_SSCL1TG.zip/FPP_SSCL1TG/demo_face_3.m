clear 
close all
addpath PROPACK
addpath Ncut_9
addpath common
addpath Algorithm-codes
addpath FyaleB
addpath Codes
% H=6;
% acc=zeros(H,7);
% tim=zeros(H,6);
% for i=1:H
%% real data human active 
n_space = 3;
cluster_size=20;
load Face3
A1=Face3; 
A = normalize(A1);
corruption=0;
% 0  0.0001   0.01  0.06
N = randn(size(A1))*corruption;
X1 = A1 + N;
X = normalize(X1);
label = [ones(cluster_size, 1); 2*ones(cluster_size, 1); 3*ones(cluster_size, 1)];
% label = [ones(cluster_size, 1); 2*ones(cluster_size, 1); 3*ones(cluster_size, 1);4*ones(cluster_size, 1);5*ones(cluster_size, 1)];
%% solve PSNR
s=max(max(A));
[u,v]=size(A);
C=A-X;
c=norm(C,'fro');
PSNR = 10*log10(s*s/(c^2/u/v));
%% running SSC
% H=1;
% acc=zeros(H,3);
% tim=zeros(H,2);
% for i=1:H
% tic;
% Z0 = ssc_exact_fro(X, 0.01);
% t0=toc;
% clusters0 = ncutW(abs(Z0) + abs(Z0'), n_space);
% final_clusters0 = condense_clusters(clusters0, 1);
% NcutDiscrete0 = clusters0;
% accuracy0 = compute_accuracy(NcutDiscrete0, label);
% % acc(i,:)=[PSNR,accuracy0];
% % tim(i,:)=[t0];
% % end
% %% running LRR
% tic;
%  Z1 = lrr_exact_l1l2(X, 0.01);
% t1=toc;
% clusters1 = ncutW(abs(Z1) + abs(Z1'), n_space);
% final_clusters1 = condense_clusters(clusters1, 1);
% NcutDiscrete1 = clusters1;
% accuracy1 = compute_accuracy(NcutDiscrete1, label);
% 
% acc(i,:)=[PSNR,accuracy0,accuracy1];
% tim(i,:)=[t0,t1];
% end
 %% running spatSC
% tic;
% lambda_1 = 0.099;
% lambda_2 = 0.1;
% Z3 = spatsc_relaxed_cvpr(X, lambda_1, lambda_2);
% t2=toc;
% clusters3 = ncutW(abs(Z3) + abs(Z3'), n_space);
% final_clusters3 = condense_clusters(clusters3, 1);
% NcutDiscrete3 = clusters3;
% accuracy2 = compute_accuracy(NcutDiscrete3, label);
% %% running v-LADMAP-OSC
% tic;
% lambda_1 = 0.099;
% lambda_2 = 0.1;
% Z4 = osc_relaxed(X, lambda_1, lambda_2);
% t3=toc;
% clusters4 = ncutW(abs(Z4) + abs(Z4'), n_space);
% final_clusters4 = condense_clusters(clusters4, 1);
% NcutDiscrete4 = clusters4;
% accuracy3 = compute_accuracy(NcutDiscrete4, label);
% %% running ADMM-TSC 
% % rand('state',123);
% 
% %%%---Load the data set---%%%
% % load('Data/P1_HIS.mat');
% 
% % paths = genpath('Codes/');
% % addpath(paths);
% 
% %%%---Normalize the data---%%%
% % X = normalize(feature);
% 
% %%%---Parameter settings---%%%
% paras = [];
% paras.lambda1 = 0.01;
% paras.lambda2 = 15;
% paras.n_d = 80;
% paras.ksize = 7;
% paras.tol = 1e-4;
% paras.maxIter = 1200;
% paras.stepsize = 0.1;
% tic;
% %%%---Learn representations Z---%%%
% [D, Z, err] = TSC_ADMM(X,paras);
% t4 = toc;
% % disp('Segmentation...');
% %%%---Graph construction and segmentation---%%%
% 
% nbCluster = length(unique(label));
% vecNorm = sum(Z.^2);
% W2 = (Z'*Z) ./ (vecNorm'*vecNorm + 1e-6);
% 
% [oscclusters,~,~] = ncutW(W2,nbCluster);
% clusters = denseSeg(oscclusters, 1);
% 
% accuracy4 = compacc(clusters, label);

%% running FPEMS-WOSC  0.5  0.1
% H=1;
% acc=zeros(H,2);
% tim=zeros(H,1);
% for i=1:H
rho = 0.5;
t = 100;
[~,n] = size(A1);
V = A1 + N;
H1=makeupW(V,t);
H = diag(H1);
R = (triu(ones(n,n-1),1) - triu(ones(n, n-1))) + (triu(ones(n, n-1),-1)-triu(ones(n, n-1)));
% gamma=1.01*(norm(R*H)^2/mu+2*(norm(X')^2));
lambda1 = 0.5;
lambda2 = 0.5;
tic;
Y = FPP_RoSeSC(X,H,lambda1,lambda2,rho);
Z6=Y';
t5=toc;
clusters6 = ncutW(abs(Z6) + abs(Z6'), n_space);
final_clusters6 = condense_clusters(clusters6, 1);
NcutDiscrete6 = clusters6;
accuracy5 = compute_accuracy(NcutDiscrete6, label);
% acc(i,:)=[PSNR,accuracy5];
% tim(i,:)=[t5];
% end
%% running ADMM-LpWOSC  
% tic;
% lambda1=0.099;
% lambda2=0.001;
% eta_h=10000;  eta_g=10000;  
% rho=1.8;
% p1=0.01;
% Z  = ADMM_LpWOSC(X,lambda1,lambda2,eta_h,eta_g,rho,p1);
% t6=toc;
% clusters = ncutW(abs(Z) + abs(Z'), n_space);
% final_clusters = condense_clusters(clusters, 1);
% NcutDiscrete = clusters;
% accuracy6 = compute_accuracy(NcutDiscrete, label);
%% disp  five affinity matrices
% figure,imagesc(Z0),xlabel('SSC');
% figure,imagesc(Z1),xlabel('LRR');
% figure,imagesc(Z3),xlabel('spatSC');
% figure,imagesc(Z4),xlabel('OSC-v-LADMAP');
% figure,imagesc(W2),xlabel('TSC-ADMM');
%  figure,imagesc(Z6),xlabel('WOSC-FPEMS');
% 
%  plotClusters(final_clusters0);xlabel('SSC');
% plotClusters(final_clusters1);xlabel('LRR');
% plotClusters(final_clusters3);xlabel('spatSC');
% plotClusters(final_clusters4);xlabel('OSC-v-LADMAP');
% plotClusters(clusters);xlabel('TSC-ADMM');
%  plotClusters(final_clusters6);xlabel('WOSC-FPEMS');

%% disp  accuracy
% fprintf('   PSNR   accuracy1   accuracy3   accuracy4   accuracy6\n');
% fprintf('%7.4f   %7.4f     %7.4f     %7.4f     %7.4f\n',PSNR,accuracy1,accuracy3,accuracy4,accuracy6);
% fprintf('    t1        t3          t4         t6\n');
% fprintf(' %7.4f     %7.4f    %7.4f    %7.4f\n',t1,t3,t4,t6);
% acc(i,:)=[PSNR,accuracy0,accuracy1,accuracy2,accuracy3,accuracy4, accuracy5];
% tim(i,:)=[t0,t1,t2,t3,t4,t5];
% end